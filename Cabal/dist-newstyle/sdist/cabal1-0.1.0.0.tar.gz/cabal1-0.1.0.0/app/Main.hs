module Cabal where

import Codec.Picture
import Data.Array.Repa as R
import Data.Array.Repa.Algorithms.Convolve

-- Convertir una imagen de JuicyPixels a una matriz de Repa
juicyToRepa :: Image Pixel8 -> Array U DIM2 Int
juicyToRepa img = fromListUnboxed (Z :. h :. w) (toList (imageData img))
  where
    (w, h) = (imageWidth img, imageHeight img)

-- Convertir una matriz de Repa a una imagen de JuicyPixels
repaToJuicy :: Array U DIM2 Int -> Image Pixel8
repaToJuicy arr = generateImage (\x y -> fromIntegral (arr R.! (Z :. y :. x))) w h
  where
    (Z :. h :. w) = extent arr

main :: IO ()
main = do
  -- Cargar una imagen desde un archivo
  eitherImg <- readImage "ruta/de/tu/imagen.png"
  case eitherImg of
    Left err -> putStrLn ("Error al cargar la imagen: " ++ err)
    Right dynImg -> do
      let img = convertLuma8 dynImg  -- Convertir la imagen a escala de grises
      let repaImg = juicyToRepa img  -- Convertir a matriz de Repa
      -- Definir un kernel de convolución (por ejemplo, filtro de desenfoque)
      let kernel = fromListUnboxed (Z :. 3 :. 3) [1, 1, 1, 1, 1, 1, 1, 1, 1]
      -- Aplicar el filtro de convolución
      let convolved = computeUnboxedS (convolveOut (Z :. (1 :: Int) :. (1 :: Int)) kernel repaImg)
      -- Convertir de vuelta a imagen de JuicyPixels
      let processedImg = repaToJuicy convolved
      -- Guardar la imagen procesada
      savePngImage "ruta/de/tu/imagen_procesada.png" (ImageY8 processedImg)
